package com.iliya.assistant

import java.net.URI

/** Small platform-independent helpers covered by JVM unit tests. */
object AssistantCore {
    fun isValidHttpsEndpoint(raw: String): Boolean {
        val value = raw.trim()
        if (value.isEmpty() || value.length > 2048) return false
        val uri = runCatching { URI(value) }.getOrNull() ?: return false
        return uri.scheme.equals("https", ignoreCase = true) &&
            !uri.host.isNullOrBlank() &&
            uri.userInfo == null &&
            uri.fragment == null
    }

    fun cleanUserText(value: String, maxLength: Int = 1200): String =
        value.trim().replace("\u0000", "").take(maxLength.coerceAtLeast(1))

    fun languageCode(isPersian: Boolean): String = if (isPersian) "fa" else "en"
}
