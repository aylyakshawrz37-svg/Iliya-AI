package com.iliya.assistant

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.CalendarContract
import android.provider.ContactsContract
import android.telephony.SmsManager
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import java.util.concurrent.Executors
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

private data class ChatMessage(val role: String, val text: String)
private data class TaskItem(val id: Int, val text: String, val done: Boolean)

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private val bg = Color.rgb(12, 17, 24)
    private val panel = Color.rgb(20, 28, 39)
    private val panelAlt = Color.rgb(28, 38, 52)
    private val ink = Color.rgb(240, 245, 249)
    private val muted = Color.rgb(153, 169, 184)
    private val accent = Color.rgb(99, 216, 209)
    private val executor = Executors.newSingleThreadExecutor()
    private val messages = mutableListOf<ChatMessage>()
    private val tasks = mutableListOf<TaskItem>()
    private val notes = mutableListOf<String>()
    private val memories = mutableListOf<String>()

    private lateinit var prefs: android.content.SharedPreferences
    private lateinit var pageHost: LinearLayout
    private lateinit var navBar: LinearLayout
    private lateinit var tts: TextToSpeech
    private var ttsReady = false
    private var isPersian = true
    private var currentPage = "chat"
    private var messageInput: EditText? = null
    private var activeChatBubbleList: LinearLayout? = null
    private var activeChatScroll: ScrollView? = null
    private var speechRecognizer: SpeechRecognizer? = null
    private var isSending = false
    private var pendingPermissionAction: (() -> Unit)? = null
    private var pendingPermissionDeniedMessage: String = ""

    private val assistantEndpoint: String
        get() = prefs.getString(KEY_ENDPOINT, DEFAULT_ENDPOINT) ?: DEFAULT_ENDPOINT

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = 0
        prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        isPersian = prefs.getBoolean(KEY_LANGUAGE, true)
        loadData()
        tts = TextToSpeech(this, this)
        requestNotificationPermissionIfNeeded()
        buildShell()
        showPage("chat")
    }

    override fun onInit(status: Int) {
        ttsReady = status == TextToSpeech.SUCCESS
        if (ttsReady) setTtsLanguage()
    }

    private fun setTtsLanguage() {
        if (!ttsReady) return
        val language = if (isPersian) Locale("fa", "IR") else Locale.US
        val result = tts.setLanguage(language)
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            tts.setLanguage(Locale.US)
            toast(if (isPersian) "صدای فارسی روی گوشی نصب نیست؛ صدای انگلیسی جایگزین می‌شود." else "The selected voice is unavailable; English voice will be used.")
        }
    }

    private fun loadData() {
        runCatching {
            val array = JSONArray(prefs.getString(KEY_MESSAGES, "[]"))
            for (i in 0 until array.length()) {
                val item = array.optJSONObject(i) ?: continue
                val role = item.optString("role")
                if (role == "user" || role == "assistant") {
                    messages.add(ChatMessage(role, item.optString("text")))
                }
            }
        }
        runCatching {
            val array = JSONArray(prefs.getString(KEY_TASKS, "[]"))
            for (i in 0 until array.length()) {
                val item = array.optJSONObject(i) ?: continue
                tasks.add(TaskItem(item.optInt("id"), item.optString("text"), item.optBoolean("done")))
            }
        }
        runCatching {
            val array = JSONArray(prefs.getString(KEY_NOTES, "[]"))
            for (i in 0 until array.length()) notes.add(array.optString(i))
        }
        runCatching {
            val array = JSONArray(prefs.getString(KEY_MEMORIES, "[]"))
            for (i in 0 until array.length()) memories.add(array.optString(i))
        }
    }

    private fun persistMessages() {
        val array = JSONArray()
        messages.takeLast(MAX_SAVED_MESSAGES).forEach {
            array.put(JSONObject().put("role", it.role).put("text", it.text))
        }
        prefs.edit().putString(KEY_MESSAGES, array.toString()).apply()
    }

    private fun persistTasks() {
        val array = JSONArray()
        tasks.forEach {
            array.put(JSONObject().put("id", it.id).put("text", it.text).put("done", it.done))
        }
        prefs.edit().putString(KEY_TASKS, array.toString()).apply()
    }

    private fun persistNotes() {
        val array = JSONArray()
        notes.forEach { array.put(it) }
        prefs.edit().putString(KEY_NOTES, array.toString()).apply()
    }

    private fun persistMemories() {
        val array = JSONArray()
        memories.forEach { array.put(it) }
        prefs.edit().putString(KEY_MEMORIES, array.toString()).apply()
    }

    private fun buildShell() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            layoutDirection = direction()
            setPadding(dp(16), dp(12), dp(16), dp(8))
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = direction()
            setPadding(0, dp(8), 0, dp(14))
        }
        val brand = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        brand.addView(label("ILIYA AI", 19, ink, true))
        brand.addView(label(if (isPersian) "دستیار شخصی ایلیا" else "Iliya's personal assistant", 12, muted))
        header.addView(brand, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        header.addView(actionButton(if (isPersian) "EN" else "FA", true) {
            isPersian = !isPersian
            prefs.edit().putBoolean(KEY_LANGUAGE, isPersian).apply()
            setTtsLanguage()
            buildShell()
            showPage(currentPage)
        })
        root.addView(header)

        pageHost = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = direction()
        }
        root.addView(pageHost, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        navBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            layoutDirection = direction()
            setPadding(0, dp(8), 0, dp(2))
        }
        root.addView(navBar)
        setContentView(root)
        updateNavigation()
    }

    private fun updateNavigation() {
        navBar.removeAllViews()
        val items = listOf(
            "chat" to if (isPersian) "چت" else "Chat",
            "tasks" to if (isPersian) "کارها" else "Tasks",
            "notes" to if (isPersian) "یادداشت" else "Notes",
            "memory" to if (isPersian) "حافظه" else "Memory",
            "tools" to if (isPersian) "ابزار" else "Tools"
        )
        items.forEach { (key, title) ->
            val button = actionButton(title, currentPage == key) { showPage(key) }
            button.textSize = 11f
            navBar.addView(
                button,
                LinearLayout.LayoutParams(0, dp(44), 1f).apply {
                    marginStart = dp(2)
                    marginEnd = dp(2)
                }
            )
        }
    }

    private fun showPage(page: String) {
        currentPage = page
        pageHost.removeAllViews()
        updateNavigation()
        when (page) {
            "tasks" -> showTasks()
            "notes" -> showNotes()
            "memory" -> showMemories()
            "tools" -> showTools()
            else -> showChat()
        }
    }

    private fun showChat() {
        val intro = card()
        intro.addView(label(if (isPersian) "سلام ایلیا" else "Hello, Iliya", 21, ink, true))
        intro.addView(
            label(
                if (isPersian) "درخواستت را بنویس یا با صدا بگو. می‌توانم در درس، برنامه‌ریزی و کارهای روزمره کمک کنم."
                else "Type or speak a request. I can help with learning, planning and everyday tasks.",
                13,
                muted
            )
        )
        pageHost.addView(intro, matchWrap())

        val scroll = ScrollView(this).apply {
            isFillViewport = false
            clipToPadding = false
            setPadding(0, dp(8), 0, dp(8))
        }
        val bubbleList = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = direction()
        }
        if (messages.isEmpty()) {
            addMessageBubble(
                bubbleList,
                ChatMessage("assistant", if (isPersian) "سلام. امروز چه کاری برات انجام بدم؟" else "Hello. What should we work on today?")
            )
        } else {
            messages.takeLast(MAX_VISIBLE_MESSAGES).forEach { addMessageBubble(bubbleList, it) }
        }
        scroll.addView(bubbleList)
        activeChatBubbleList = bubbleList
        activeChatScroll = scroll
        pageHost.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val composer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = direction()
            setPadding(0, dp(4), 0, dp(4))
        }
        val input = EditText(this).apply {
            setTextColor(ink)
            setHintTextColor(muted)
            textSize = 15f
            hint = if (isPersian) "پیامت رو بنویس..." else "Write your message..."
            setSingleLine(false)
            maxLines = 4
            imeOptions = EditorInfo.IME_ACTION_SEND
            setPadding(dp(13), dp(9), dp(13), dp(9))
            background = rounded(panelAlt, 18)
            layoutDirection = direction()
            textDirection = if (isPersian) View.TEXT_DIRECTION_RTL else View.TEXT_DIRECTION_LTR
        }
        messageInput = input
        composer.addView(input, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        composer.addView(
            actionButton("🎙", false) { startVoiceInput() },
            LinearLayout.LayoutParams(dp(46), dp(46)).apply { marginStart = dp(6) }
        )
        val sendButton = actionButton(if (isPersian) "ارسال" else "Send", true) {
            val value = AssistantCore.cleanUserText(input.text?.toString().orEmpty())
            if (value.isNotEmpty()) {
                input.setText("")
                sendMessage(value, bubbleList, scroll)
            }
        }
        composer.addView(
            sendButton,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(46)).apply { marginStart = dp(6) }
        )
        input.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                sendButton.performClick()
                true
            } else false
        }
        pageHost.addView(composer)
    }

    private fun sendMessage(text: String, bubbleList: LinearLayout, scroll: ScrollView) {
        if (isSending) {
            toast(if (isPersian) "درخواست قبلی هنوز در حال پردازش است." else "The previous request is still running.")
            return
        }
        val deviceCommand = parseDeviceCommand(text)
        if (deviceCommand != null) {
            val userMessage = ChatMessage("user", text)
            messages.add(userMessage)
            persistMessages()
            addMessageBubble(bubbleList, userMessage)
            val acknowledgement = when (deviceCommand) {
                is DeviceCommand.Call -> if (isPersian) "فرمان تماس دریافت شد؛ دارم شماره را پیدا و شماره‌گیری می‌کنم." else "Call command received. Finding the number and placing the call."
                is DeviceCommand.Sms -> if (isPersian) "فرمان پیام دریافت شد؛ دارم پیامک را ارسال می‌کنم." else "Message command received. Sending the SMS."
            }
            val response = ChatMessage("assistant", acknowledgement)
            messages.add(response)
            persistMessages()
            addMessageBubble(bubbleList, response)
            scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
            speak(acknowledgement)
            when (deviceCommand) {
                is DeviceCommand.Call -> executeDirectCall(deviceCommand.target)
                is DeviceCommand.Sms -> executeDirectSms(deviceCommand.target, deviceCommand.body)
            }
            return
        }
        isSending = true
        messageInput?.isEnabled = false
        val historyBeforeRequest = messages.toList()
        val memoriesAtSend = memories.toList()
        val notesAtSend = notes.toList()
        val openTasksAtSend = tasks.filterNot { it.done }.map { it.text }
        val languageAtSend = isPersian
        val userMessage = ChatMessage("user", text)
        messages.add(userMessage)
        persistMessages()
        addMessageBubble(bubbleList, userMessage)
        val waitingView = addMessageBubble(
            bubbleList,
            ChatMessage("assistant", if (languageAtSend) "دارم بررسی می‌کنم..." else "Thinking...")
        )
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }

        executor.execute {
            val answer = requestAssistant(
                text,
                historyBeforeRequest,
                memoriesAtSend,
                notesAtSend,
                openTasksAtSend,
                languageAtSend
            )
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                isSending = false
                messageInput?.isEnabled = true
                (waitingView.parent as? ViewGroup)?.removeView(waitingView)
                val response = ChatMessage("assistant", answer)
                messages.add(response)
                persistMessages()
                addMessageBubble(bubbleList, response)
                scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
                speak(answer)
            }
        }
    }

    private sealed class DeviceCommand {
        data class Call(val target: String) : DeviceCommand()
        data class Sms(val target: String, val body: String) : DeviceCommand()
    }

    /** Only explicit, imperative phrases are treated as device commands. */
    private fun parseDeviceCommand(raw: String): DeviceCommand? {
        val text = normalizeCommandText(raw)
            .removePrefix("ایلیا ")
            .removePrefix("iliya ")
            .trim(' ', '.', '،', ',', '!', '؟', '?')

        val smsPatterns = listOf(
            Regex("^(?:به\\s+)?(.+?)\\s+(?:پیامک|پیام)\\s+(?:بده|بفرست)\\s+(.+)$"),
            Regex("^(?:پیامک|پیام)\\s+به\\s+(.+?)\\s+(?:بده|بفرست)\\s+(.+)$"),
            Regex("^send\\s+(?:an?\\s+)?(?:sms|text|message)\\s+to\\s+(.+?)\\s+(?:saying|:|that says)\\s+(.+)$", RegexOption.IGNORE_CASE)
        )
        for (pattern in smsPatterns) {
            val match = pattern.find(text) ?: continue
            val target = cleanCommandTarget(match.groupValues[1])
            val body = AssistantCore.cleanUserText(match.groupValues[2], 1000)
            if (target.isNotBlank() && body.isNotBlank()) return DeviceCommand.Sms(target, body)
        }

        val callPatterns = listOf(
            Regex("^(?:به|با)\\s+(.+?)\\s+(?:زنگ\\s+بزن|تماس\\s+بگیر|تماس\\s+بزن|تماس\\s+برقرار\\s+کن)$"),
            Regex("^(.+?)\\s+رو\\s+زنگ\\s+بزن$"),
            Regex("^(?:call|phone)\\s+(.+)$", RegexOption.IGNORE_CASE)
        )
        for (pattern in callPatterns) {
            val match = pattern.find(text) ?: continue
            val target = cleanCommandTarget(match.groupValues[1])
            if (target.isNotBlank()) return DeviceCommand.Call(target)
        }
        return null
    }

    private fun normalizeCommandText(raw: String): String {
        val digitMap = mapOf(
            '۰' to '0', '۱' to '1', '۲' to '2', '۳' to '3', '۴' to '4',
            '۵' to '5', '۶' to '6', '۷' to '7', '۸' to '8', '۹' to '9',
            '٠' to '0', '١' to '1', '٢' to '2', '٣' to '3', '٤' to '4',
            '٥' to '5', '٦' to '6', '٧' to '7', '٨' to '8', '٩' to '9'
        )
        return raw.trim()
            .replace('ي', 'ی')
            .replace('ك', 'ک')
            .map { digitMap[it] ?: it }
            .joinToString("")
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    private fun cleanCommandTarget(value: String): String = value
        .trim()
        .removePrefix("شماره ")
        .removePrefix("شماره‌ی ")
        .trim(' ', '.', '،', ',', '!', '؟', '?', '"', '\'')

    private fun normalizePhoneNumber(value: String): String? {
        val normalized = normalizeCommandText(value)
        val compact = normalized.replace(Regex("[\\s()\\-]"), "")
        if (!Regex("^\\+?[0-9]{5,20}$").matches(compact)) return null
        return compact
    }

    private fun runWithPermission(permission: String, requestCode: Int, deniedMessage: String, action: () -> Unit) {
        if (checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED) {
            runCatching(action).onFailure { toast(if (isPersian) "اجرای فرمان ناموفق بود: ${it.message ?: "خطای نامشخص"}" else "Command failed: ${it.message ?: "unknown error"}") }
            return
        }
        pendingPermissionAction = action
        pendingPermissionDeniedMessage = deniedMessage
        requestPermissions(arrayOf(permission), requestCode)
    }

    private fun resolvePhoneTarget(target: String, onResolved: (String?) -> Unit) {
        normalizePhoneNumber(target)?.let {
            onResolved(it)
            return
        }
        val lookup = {
            var found: String? = null
            runCatching {
                val uri = Uri.withAppendedPath(
                    ContactsContract.CommonDataKinds.Phone.CONTENT_FILTER_URI,
                    Uri.encode(target)
                )
                contentResolver.query(
                    uri,
                    arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
                    null,
                    null,
                    null
                )?.use { cursor ->
                    if (cursor.moveToFirst()) found = cursor.getString(0)
                }
            }
            onResolved(found?.let { normalizePhoneNumber(it) })
        }
        if (checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED) {
            lookup()
        } else {
            pendingPermissionAction = lookup
            pendingPermissionDeniedMessage = if (isPersian) "برای پیدا کردن مخاطب، مجوز مخاطبین لازم است. می‌توانی به‌جای نام، شماره کامل را بگویی." else "Contacts permission is needed to look up that person. You can say the full number instead."
            requestPermissions(arrayOf(Manifest.permission.READ_CONTACTS), REQUEST_CONTACTS)
        }
    }

    private fun executeDirectCall(target: String) {
        resolvePhoneTarget(target) { number ->
            if (number.isNullOrBlank()) {
                toast(if (isPersian) "شماره پیدا نشد؛ نام مخاطب یا شماره را بررسی کن." else "Number not found. Check the contact name or number.")
                return@resolvePhoneTarget
            }
            runWithPermission(
                Manifest.permission.CALL_PHONE,
                REQUEST_CALL,
                if (isPersian) "برای تماس مستقیم، مجوز تماس را در تنظیمات برنامه فعال کن." else "Allow the phone permission to place direct calls."
            ) {
                startActivity(Intent(Intent.ACTION_CALL, Uri.fromParts("tel", number, null)))
            }
        }
    }

    private fun executeDirectSms(target: String, body: String) {
        resolvePhoneTarget(target) { number ->
            if (number.isNullOrBlank()) {
                toast(if (isPersian) "شماره مخاطب پیدا نشد؛ نام یا شماره را بررسی کن." else "Contact number not found. Check the name or number.")
                return@resolvePhoneTarget
            }
            runWithPermission(
                Manifest.permission.SEND_SMS,
                REQUEST_SMS,
                if (isPersian) "برای ارسال پیامک مستقیم، مجوز پیامک لازم است." else "SMS permission is required to send messages directly."
            ) {
                val manager = if (Build.VERSION.SDK_INT >= 31) {
                    getSystemService(SmsManager::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    SmsManager.getDefault()
                }
                val parts = manager.divideMessage(body)
                if (parts.size > 1) {
                    manager.sendMultipartTextMessage(number, null, parts, null, null)
                } else {
                    manager.sendTextMessage(number, null, body, null, null)
                }
                toast(if (isPersian) "درخواست ارسال پیامک به سیستم مخابرات داده شد." else "SMS submission was handed to the carrier service.")
            }
        }
    }

    private fun requestAssistant(
        message: String,
        previous: List<ChatMessage>,
        savedMemories: List<String>,
        savedNotes: List<String>,
        openTasks: List<String>,
        languagePersian: Boolean
    ): String {
        var connection: HttpURLConnection? = null
        return try {
            val endpoint = assistantEndpoint
            if (!AssistantCore.isValidHttpsEndpoint(endpoint)) {
                return if (languagePersian) "نشانی سرور معتبر نیست. از بخش ابزارها آن را اصلاح کن." else "The server address is invalid. Update it in Tools."
            }
            connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 12000
                readTimeout = 30000
                doOutput = true
                useCaches = false
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
                setRequestProperty("Accept", "application/json")
                readEncryptedAccessToken()?.takeIf { it.isNotBlank() }?.let {
                    setRequestProperty("Authorization", "Bearer $it")
                }
            }

            val history = JSONArray()
            previous.takeLast(8).forEach { item ->
                history.put(
                    JSONObject()
                        .put("role", item.role)
                        .put("content", AssistantCore.cleanUserText(item.text, 1000))
                )
            }

            val memoryContext = JSONArray().apply {
                savedMemories.take(12).forEach { put(AssistantCore.cleanUserText(it, 300)) }
            }
            val notesContext = JSONArray().apply {
                savedNotes.take(8).forEach { put(AssistantCore.cleanUserText(it, 300)) }
            }
            val body = JSONObject()
                .put("message", AssistantCore.cleanUserText(message, 1200))
                .put("language", AssistantCore.languageCode(languagePersian))
                .put("history", history)
                .put("memory", memoryContext)
                .put("notes", notesContext)
                .put("tasks", JSONArray(openTasks.take(12)))

            connection.outputStream.use { output ->
                output.write(body.toString().toByteArray(Charsets.UTF_8))
            }
            val status = connection.responseCode
            val stream = if (status in 200..299) connection.inputStream else connection.errorStream
            val raw = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            val result = runCatching { JSONObject(raw) }.getOrNull()
            val reply = result?.optString("reply")?.takeIf { it.isNotBlank() && it != "null" }
            val serverError = result?.optString("error")
            if (reply != null) reply
            else if (serverError == "backend_not_configured") {
                if (languagePersian) "سرور هنوز APP_TOKEN ندارد. راه‌اندازی بک‌اند را طبق راهنمای پروژه کامل کن." else "The backend has no APP_TOKEN configured yet. Finish the backend setup in the project guide."
            } else if (serverError == "unauthorized") {
                if (languagePersian) "توکن دسترسی اشتباه است؛ از بخش ابزارها اصلاحش کن." else "The access token is incorrect. Update it in Tools."
            } else when (status) {
                401, 403 -> if (languagePersian) "توکن دسترسی سرور معتبر نیست. از بخش ابزارها تنظیمش کن." else "The server access token is invalid. Update it in Tools."
                429 -> if (languagePersian) "درخواست‌ها موقتاً زیاد شده‌اند. کمی بعد دوباره امتحان کن." else "The service is busy. Please try again shortly."
                in 500..599 -> if (languagePersian) "سرویس هوش مصنوعی موقتاً در دسترس نیست." else "The AI service is temporarily unavailable."
                else -> if (languagePersian) "پاسخ معتبری از سرور دریافت نشد. (HTTP $status)" else "The server returned no usable response. (HTTP $status)"
            }
        } catch (_: Exception) {
            if (languagePersian) "اتصال به دستیار برقرار نشد. اینترنت و نشانی سرور را بررسی کن." else "I couldn't reach the assistant. Check the internet connection and server address."
        } finally {
            connection?.disconnect()
        }
    }

    private fun addMessageBubble(container: LinearLayout, message: ChatMessage): View {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = if (message.role == "user") Gravity.START else Gravity.END
            layoutDirection = direction()
            setPadding(0, dp(3), 0, dp(3))
        }
        val text = TextView(this).apply {
            this.text = message.text
            setTextColor(ink)
            textSize = 15f
            setPadding(dp(14), dp(11), dp(14), dp(11))
            background = rounded(if (message.role == "user") Color.rgb(34, 61, 88) else panelAlt, 17)
            maxWidth = resources.displayMetrics.widthPixels * 4 / 5
            gravity = if (isPersian) Gravity.RIGHT else Gravity.LEFT
            textDirection = if (isPersian) View.TEXT_DIRECTION_RTL else View.TEXT_DIRECTION_LTR
        }
        outer.addView(text)
        container.addView(outer, matchWrap())
        return outer
    }

    private fun showTasks() {
        val top = card()
        top.addView(label(if (isPersian) "کارهای من" else "My tasks", 20, ink, true))
        top.addView(label(if (isPersian) "کارها فقط روی همین گوشی ذخیره می‌شوند." else "Tasks are stored locally on this phone.", 12, muted))
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = direction()
            gravity = Gravity.CENTER_VERTICAL
        }
        val input = EditText(this).apply {
            setTextColor(ink)
            setHintTextColor(muted)
            hint = if (isPersian) "یک کار جدید..." else "Add a task..."
            setPadding(dp(12), dp(8), dp(12), dp(8))
            background = rounded(panelAlt, 14)
            textSize = 14f
        }
        row.addView(input, LinearLayout.LayoutParams(0, dp(48), 1f))
        row.addView(
            actionButton(if (isPersian) "افزودن" else "Add", true) {
                val text = AssistantCore.cleanUserText(input.text.toString(), 240)
                if (text.isNotEmpty()) {
                    tasks.add(0, TaskItem(newLocalId(), text, false))
                    persistTasks()
                    showPage("tasks")
                }
            },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(48)).apply { marginStart = dp(7) }
        )
        top.addView(row)
        pageHost.addView(top, matchWrap())

        val scroll = ScrollView(this)
        val list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = direction()
        }
        tasks.forEach { item ->
            val taskCard = card().apply { setPadding(dp(11), dp(8), dp(11), dp(8)) }
            val taskRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                layoutDirection = direction()
            }
            val check = CheckBox(this).apply {
                isChecked = item.done
                buttonTintList = android.content.res.ColorStateList.valueOf(accent)
                setOnCheckedChangeListener { _, checked ->
                    val index = tasks.indexOfFirst { it.id == item.id }
                    if (index >= 0) {
                        tasks[index] = item.copy(done = checked)
                        persistTasks()
                        showPage("tasks")
                    }
                }
            }
            taskRow.addView(check)
            val taskText = label(item.text, 14, if (item.done) muted else ink)
            if (item.done) taskText.paintFlags = taskText.paintFlags or android.graphics.Paint.STRIKE_THRU_TEXT_FLAG
            taskRow.addView(taskText, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            taskCard.addView(taskRow)

            val actions = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutDirection = direction()
            }
            actions.addView(actionButton(if (isPersian) "یادآوری" else "Remind", false) { chooseReminder(item.text, item.id) })
            actions.addView(
                actionButton(if (isPersian) "حذف" else "Delete", false) {
                    ReminderScheduler.cancel(this@MainActivity, item.id)
                    tasks.removeAll { it.id == item.id }
                    persistTasks()
                    showPage("tasks")
                },
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(40)).apply { marginStart = dp(6) }
            )
            taskCard.addView(actions)
            list.addView(taskCard, matchWrap())
        }
        if (tasks.isEmpty()) {
            list.addView(
                label(if (isPersian) "هنوز کاری ثبت نکردی." else "No tasks yet.", 14, muted)
                    .apply { setPadding(dp(6), dp(20), dp(6), dp(20)) }
            )
        }
        scroll.addView(list)
        pageHost.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
    }

    private fun chooseReminder(taskText: String, taskId: Int) {
        val now = Calendar.getInstance()
        val datePicker = DatePickerDialog(
            this,
            { _, year, month, day ->
                TimePickerDialog(
                    this,
                    { _, hour, minute ->
                        val calendar = Calendar.getInstance().apply {
                            set(year, month, day, hour, minute, 0)
                            set(Calendar.MILLISECOND, 0)
                        }
                        if (calendar.timeInMillis <= System.currentTimeMillis()) {
                            toast(if (isPersian) "زمان یادآوری باید در آینده باشد." else "Choose a future time.")
                            return@TimePickerDialog
                        }
                        val reminder = StoredReminder(
                            taskId,
                            calendar.timeInMillis,
                            if (isPersian) "یادآوری از Iliya AI" else "Iliya AI reminder",
                            taskText
                        )
                        ReminderStore.save(this, reminder)
                        ReminderScheduler.schedule(this, reminder)
                        val formatter = SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.getDefault())
                        toast((if (isPersian) "یادآوری تنظیم شد: " else "Reminder set: ") + formatter.format(calendar.time))
                    },
                    now.get(Calendar.HOUR_OF_DAY),
                    now.get(Calendar.MINUTE),
                    true
                ).show()
            },
            now.get(Calendar.YEAR),
            now.get(Calendar.MONTH),
            now.get(Calendar.DAY_OF_MONTH)
        )
        datePicker.datePicker.minDate = System.currentTimeMillis()
        datePicker.show()
    }

    private fun showNotes() {
        val top = card()
        top.addView(label(if (isPersian) "یادداشت‌های من" else "My notes", 20, ink, true))
        val input = EditText(this).apply {
            setTextColor(ink)
            setHintTextColor(muted)
            hint = if (isPersian) "اینجا بنویس..." else "Write something..."
            minLines = 3
            gravity = Gravity.TOP
            textSize = 14f
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = rounded(panelAlt, 14)
            layoutDirection = direction()
            textDirection = if (isPersian) View.TEXT_DIRECTION_RTL else View.TEXT_DIRECTION_LTR
        }
        top.addView(input, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(110)))
        top.addView(actionButton(if (isPersian) "ذخیره یادداشت" else "Save note", true) {
            val text = AssistantCore.cleanUserText(input.text.toString(), 1500)
            if (text.isNotEmpty()) {
                notes.add(0, text)
                persistNotes()
                showPage("notes")
            }
        })
        pageHost.addView(top, matchWrap())

        val scroll = ScrollView(this)
        val list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = direction()
        }
        notes.forEachIndexed { index, note ->
            val noteCard = card()
            noteCard.addView(label(note, 14, ink))
            noteCard.addView(actionButton(if (isPersian) "حذف" else "Delete", false) {
                notes.removeAt(index)
                persistNotes()
                showPage("notes")
            })
            list.addView(noteCard, matchWrap())
        }
        if (notes.isEmpty()) {
            list.addView(label(if (isPersian) "هنوز یادداشتی نداری." else "No notes yet.", 14, muted).apply {
                setPadding(dp(6), dp(20), dp(6), dp(20))
            })
        }
        scroll.addView(list)
        pageHost.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
    }

    private fun showMemories() {
        val top = card()
        top.addView(label(if (isPersian) "حافظهٔ شخصی" else "Personal memory", 20, ink, true))
        top.addView(
            label(
                if (isPersian) "نکته‌هایی را که می‌خواهی دستیار در گفتگوهای بعدی بداند ثبت کن. این موارد هنگام چت برای شخصی‌سازی به سرور هوش مصنوعی فرستاده می‌شوند. رمز، کد ورود یا اطلاعات بانکی ذخیره نکن."
                else "Save details you want the assistant to remember in future chats. These items are sent to the AI server with chat requests. Never save passwords, login codes or banking details.",
                12,
                muted
            )
        )
        val input = EditText(this).apply {
            setTextColor(ink)
            setHintTextColor(muted)
            hint = if (isPersian) "مثلاً پاسخ‌ها کوتاه و مستقیم باشند..." else "For example: Keep answers concise and direct..."
            minLines = 2
            gravity = Gravity.TOP
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = rounded(panelAlt, 14)
            textSize = 14f
        }
        top.addView(input, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(92)))
        top.addView(actionButton(if (isPersian) "ذخیره در حافظه" else "Save to memory", true) {
            val value = AssistantCore.cleanUserText(input.text.toString(), 400)
            if (value.isNotEmpty()) {
                memories.add(0, value)
                persistMemories()
                showPage("memory")
            }
        })
        pageHost.addView(top, matchWrap())

        val scroll = ScrollView(this)
        val list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = direction()
        }
        memories.forEachIndexed { index, memory ->
            val item = card()
            item.addView(label(memory, 14, ink))
            item.addView(actionButton(if (isPersian) "حذف از حافظه" else "Remove", false) {
                memories.removeAt(index)
                persistMemories()
                showPage("memory")
            })
            list.addView(item, matchWrap())
        }
        if (memories.isEmpty()) {
            list.addView(label(if (isPersian) "حافظه هنوز خالی است." else "Memory is empty.", 14, muted).apply {
                setPadding(dp(6), dp(20), dp(6), dp(20))
            })
        }
        scroll.addView(list)
        pageHost.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
    }

    private fun showTools() {
        val info = card()
        info.addView(label(if (isPersian) "ابزارهای دستیار" else "Assistant tools", 20, ink, true))
        info.addView(
            label(
                if (isPersian) "با فرمان صریح تو، تماس و پیامک مستقیماً اجرا می‌شود. مجوزهای تماس، پیامک و مخاطبین را اندروید فقط هنگام نیاز می‌پرسد."
                else "Explicit commands can place calls and send SMS directly. Android asks for call, SMS, and contacts permissions only when needed.",
                12,
                muted
            )
        )

        val number = EditText(this).apply {
            setTextColor(ink)
            setHintTextColor(muted)
            hint = if (isPersian) "شماره تلفن با کد کشور" else "Phone number with country code"
            inputType = android.text.InputType.TYPE_CLASS_PHONE
            setPadding(dp(12), dp(8), dp(12), dp(8))
            background = rounded(panelAlt, 14)
            textSize = 15f
            textDirection = View.TEXT_DIRECTION_LTR
            gravity = Gravity.LEFT
        }
        info.addView(number, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)))
        val callSmsRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = direction()
        }
        callSmsRow.addView(
            actionButton(if (isPersian) "تماس مستقیم" else "Call directly", true) {
                val phone = AssistantCore.cleanUserText(number.text.toString(), 40)
                if (phone.isNotEmpty()) executeDirectCall(phone)
            },
            LinearLayout.LayoutParams(0, dp(46), 1f)
        )
        callSmsRow.addView(
            actionButton(if (isPersian) "ارسال پیامک" else "Send SMS", false) {
                val phone = AssistantCore.cleanUserText(number.text.toString(), 40)
                if (phone.isNotEmpty()) askForText(if (isPersian) "متن پیامک" else "SMS message") { body -> executeDirectSms(phone, body) }
            },
            LinearLayout.LayoutParams(0, dp(46), 1f).apply { marginStart = dp(8) }
        )
        info.addView(callSmsRow)

        info.addView(actionButton(if (isPersian) "جست‌وجوی وب" else "Search the web", false) { askForText(if (isPersian) "عبارت جست‌وجو" else "Search query") { query -> searchWeb(query) } })
        info.addView(actionButton(if (isPersian) "باز کردن تلگرام" else "Open Telegram", false) { openUrl("https://t.me/") })
        info.addView(actionButton(if (isPersian) "باز کردن واتساپ" else "Open WhatsApp", false) { openUrl("https://wa.me/") })
        info.addView(actionButton(if (isPersian) "باز کردن یوتیوب" else "Open YouTube", false) { openUrl("https://www.youtube.com/") })
        info.addView(actionButton(if (isPersian) "ساخت رویداد تقویم" else "Create calendar event", false) { createCalendarEvent() })
        info.addView(actionButton(if (isPersian) "اشتراک‌گذاری متن" else "Share text", false) { askForText(if (isPersian) "متن برای اشتراک‌گذاری" else "Text to share") { shareText(it) } })
        info.addView(actionButton(if (isPersian) "باز کردن نقشه" else "Open maps", false) { askForText(if (isPersian) "مقصد" else "Destination") { openMaps(it) } })
        info.addView(actionButton(if (isPersian) "باز کردن ماشین‌حساب" else "Open calculator", false) { openCalculator() })
        info.addView(actionButton(if (isPersian) "تنظیم زنگ هشدار" else "Set alarm", false) { askForAlarmTime() })
        info.addView(actionButton(if (isPersian) "ویرایش نشانی هوش مصنوعی" else "Edit AI endpoint", false) { editAssistantEndpoint() })
        info.addView(actionButton(if (isPersian) "تست صدای دستیار" else "Test assistant voice", false) {
            speak(if (isPersian) "سلام ایلیا. صدای دستیار آماده است." else "Hello Iliya. The assistant voice is ready.")
        })
        info.addView(actionButton(if (isPersian) "خروجی پشتیبان اطلاعات" else "Export data backup", false) { exportData() })
        info.addView(actionButton(if (isPersian) "پاک کردن تاریخچه گفتگو" else "Clear chat history", false) { confirmClearHistory() })
        info.addView(
            label(
                if (isPersian) "تماس و پیامک با فرمان صریح تو مستقیماً اجرا می‌شوند؛ ارسال پیامک به سیم‌کارت، اعتبار و پشتیبانی اپراتور بستگی دارد. یادآوری‌ها هم ممکن است تحت تأثیر محدودیت باتری باشند."
                else "Explicit commands place calls and send SMS directly. SMS depends on your SIM, credit, and carrier. Battery settings can affect reminders.",
                11,
                muted
            )
        )
        val toolsScroll = ScrollView(this).apply {
            isFillViewport = false
            addView(info)
        }
        pageHost.addView(toolsScroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
    }

    private fun confirmAndOpen(message: String, action: () -> Unit) {
        AlertDialog.Builder(this)
            .setMessage(message)
            .setNegativeButton(if (isPersian) "لغو" else "Cancel", null)
            .setPositiveButton(if (isPersian) "ادامه" else "Continue") { _, _ -> runCatching(action).onFailure { showActivityError() } }
            .show()
    }

    private fun askForText(title: String, onSubmit: (String) -> Unit) {
        val input = EditText(this).apply {
            setTextColor(ink)
            setHintTextColor(muted)
            setPadding(dp(12), dp(9), dp(12), dp(9))
            background = rounded(panelAlt, 14)
            minLines = 2
        }
        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(input)
            .setNegativeButton(if (isPersian) "لغو" else "Cancel", null)
            .setPositiveButton(if (isPersian) "ادامه" else "Continue") { _, _ ->
                val value = AssistantCore.cleanUserText(input.text.toString(), 500)
                if (value.isNotEmpty()) onSubmit(value)
            }
            .show()
    }

    private fun searchWeb(query: String) {
        val intent = Intent(Intent.ACTION_WEB_SEARCH).putExtra(android.app.SearchManager.QUERY, query)
        try {
            startActivity(intent)
        } catch (_: ActivityNotFoundException) {
            openUrl("https://www.google.com/search?q=" + Uri.encode(query))
        }
    }

    private fun createCalendarEvent() {
        val titleInput = EditText(this).apply {
            setTextColor(ink)
            setHintTextColor(muted)
            hint = if (isPersian) "عنوان رویداد" else "Event title"
            setPadding(dp(12), dp(9), dp(12), dp(9))
            background = rounded(panelAlt, 14)
        }
        AlertDialog.Builder(this)
            .setTitle(if (isPersian) "رویداد جدید" else "New event")
            .setView(titleInput)
            .setNegativeButton(if (isPersian) "لغو" else "Cancel", null)
            .setPositiveButton(if (isPersian) "باز کردن تقویم" else "Open calendar") { _, _ ->
                val title = AssistantCore.cleanUserText(titleInput.text.toString(), 160)
                if (title.isNotEmpty()) {
                    val intent = Intent(Intent.ACTION_INSERT).setData(CalendarContract.Events.CONTENT_URI)
                        .putExtra(CalendarContract.Events.TITLE, title)
                    runCatching { startActivity(intent) }.onFailure { showActivityError() }
                }
            }
            .show()
    }

    private fun shareText(value: String) {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, value)
        }
        runCatching { startActivity(Intent.createChooser(intent, if (isPersian) "اشتراک‌گذاری با" else "Share with")) }
            .onFailure { showActivityError() }
    }

    private fun openMaps(destination: String) {
        val uri = Uri.parse("geo:0,0?q=" + Uri.encode(destination))
        runCatching { startActivity(Intent(Intent.ACTION_VIEW, uri)) }
            .onFailure { openUrl("https://www.google.com/maps/search/?api=1&query=" + Uri.encode(destination)) }
    }

    private fun openCalculator() {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_CALCULATOR)
        runCatching { startActivity(intent) }.onFailure { showActivityError() }
    }

    private fun askForAlarmTime() {
        val now = Calendar.getInstance()
        TimePickerDialog(this, { _, hour, minute ->
            val message = if (isPersian) "زنگ برای ساعت %02d:%02d تنظیم شود؟".format(hour, minute)
            else "Set an alarm for %02d:%02d?".format(hour, minute)
            confirmAndOpen(message) {
                val intent = Intent(android.provider.AlarmClock.ACTION_SET_ALARM)
                    .putExtra(android.provider.AlarmClock.EXTRA_HOUR, hour)
                    .putExtra(android.provider.AlarmClock.EXTRA_MINUTES, minute)
                    .putExtra(android.provider.AlarmClock.EXTRA_SKIP_UI, false)
                startActivity(intent)
            }
        }, now.get(Calendar.HOUR_OF_DAY), now.get(Calendar.MINUTE), true).show()
    }

    private fun openUrl(url: String) {
        runCatching { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
            .onFailure { showActivityError() }
    }

    private fun editAssistantEndpoint() {
        val input = EditText(this).apply {
            setTextColor(ink)
            setHintTextColor(muted)
            setText(assistantEndpoint)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_URI
            setSingleLine(true)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = rounded(panelAlt, 14)
        }
        val tokenInput = EditText(this).apply {
            setTextColor(ink)
            setHintTextColor(muted)
            hint = if (readEncryptedAccessToken().isNullOrBlank()) {
                if (isPersian) "توکن دسترسی (در صورت نیاز)" else "Access token (if required)"
            } else {
                if (isPersian) "توکن ذخیره شده؛ برای جایگزینی وارد کن" else "Token saved; enter a new one to replace"
            }
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            setSingleLine(true)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = rounded(panelAlt, 14)
        }
        val clearToken = CheckBox(this).apply {
            text = if (isPersian) "حذف توکن ذخیره‌شده" else "Clear saved token"
            setTextColor(muted)
            buttonTintList = android.content.res.ColorStateList.valueOf(accent)
        }
        val form = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(4), dp(4), dp(4), dp(4))
            addView(input, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)))
            addView(tokenInput, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)).apply { topMargin = dp(8) })
            addView(clearToken)
            addView(label(
                if (isPersian) "توکن فقط با رمزنگاری Android Keystore روی گوشی نگهداری می‌شود؛ آن را در سورس یا GitHub قرار نده. اگر سرورت توکن نمی‌خواهد، این بخش را خالی بگذار."
                else "The token is encrypted with Android Keystore on this phone. Never put it in source code or GitHub. Leave it empty if your server does not require one.",
                11,
                muted
            ))
        }
        AlertDialog.Builder(this)
            .setTitle(if (isPersian) "تنظیم اتصال هوش مصنوعی" else "AI connection settings")
            .setMessage(if (isPersian) "نشانی باید HTTPS باشد. کلید API مدل را در APK قرار نده؛ فقط توکن برنامهٔ خودت را وارد کن." else "The URL must use HTTPS. Never put a model API key in the APK; enter only your app access token.")
            .setView(form)
            .setNegativeButton(if (isPersian) "لغو" else "Cancel", null)
            .setNeutralButton(if (isPersian) "بازنشانی" else "Reset") { _, _ ->
                prefs.edit().remove(KEY_ENDPOINT).apply()
                toast(if (isPersian) "نشانی پیش‌فرض بازیابی شد." else "Default endpoint restored.")
            }
            .setPositiveButton(if (isPersian) "ذخیره" else "Save", null)
            .create()
            .apply {
                setOnShowListener {
                    getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                        val endpoint = AssistantCore.cleanUserText(input.text.toString(), 2048)
                        if (!AssistantCore.isValidHttpsEndpoint(endpoint)) {
                            input.error = if (isPersian) "نشانی HTTPS معتبر نیست." else "Enter a valid HTTPS URL."
                        } else {
                            prefs.edit().putString(KEY_ENDPOINT, endpoint).apply()
                            val newToken = AssistantCore.cleanUserText(tokenInput.text.toString(), 512)
                            when {
                                clearToken.isChecked -> clearEncryptedAccessToken()
                                newToken.isNotEmpty() -> storeEncryptedAccessToken(newToken)
                            }
                            dismiss()
                            toast(if (isPersian) "تنظیمات اتصال ذخیره شد." else "Connection settings saved.")
                        }
                    }
                }
                show()
            }
    }

    private fun storeEncryptedAccessToken(token: String) {
        runCatching {
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.ENCRYPT_MODE, getOrCreateTokenKey())
            val encrypted = cipher.iv + cipher.doFinal(token.toByteArray(Charsets.UTF_8))
            prefs.edit().putString(KEY_TOKEN_ENCRYPTED, Base64.encodeToString(encrypted, Base64.NO_WRAP)).apply()
        }.onFailure {
            toast(if (isPersian) "رمزنگاری توکن روی این گوشی ناموفق بود؛ توکن ذخیره نشد." else "Token encryption failed; the token was not saved.")
        }
    }

    private fun readEncryptedAccessToken(): String? = runCatching {
        val encoded = prefs.getString(KEY_TOKEN_ENCRYPTED, null) ?: return null
        val payload = Base64.decode(encoded, Base64.NO_WRAP)
        if (payload.size <= GCM_IV_BYTES) return null
        val iv = payload.copyOfRange(0, GCM_IV_BYTES)
        val ciphertext = payload.copyOfRange(GCM_IV_BYTES, payload.size)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, getOrCreateTokenKey(), GCMParameterSpec(GCM_TAG_BITS, iv))
        String(cipher.doFinal(ciphertext), Charsets.UTF_8)
    }.getOrNull()

    private fun clearEncryptedAccessToken() {
        prefs.edit().remove(KEY_TOKEN_ENCRYPTED).apply()
    }

    private fun getOrCreateTokenKey(): SecretKey {
        val keyStore = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
        (keyStore.getKey(TOKEN_KEY_ALIAS, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE)
        val spec = KeyGenParameterSpec.Builder(
            TOKEN_KEY_ALIAS,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        )
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setRandomizedEncryptionRequired(true)
            .build()
        generator.init(spec as java.security.spec.AlgorithmParameterSpec)
        return generator.generateKey()
    }

    private fun confirmClearHistory() {
        AlertDialog.Builder(this)
            .setMessage(if (isPersian) "همه پیام‌های ذخیره‌شده پاک شوند؟" else "Delete all saved chat messages?")
            .setNegativeButton(if (isPersian) "لغو" else "Cancel", null)
            .setPositiveButton(if (isPersian) "پاک کن" else "Delete") { _, _ ->
                messages.clear()
                persistMessages()
                showPage("chat")
            }
            .show()
    }

    private fun exportData() {
        val data = JSONObject()
            .put("schemaVersion", 1)
            .put("exportedAt", System.currentTimeMillis())
            .put("tasks", JSONArray().also { array -> tasks.forEach { array.put(JSONObject().put("id", it.id).put("text", it.text).put("done", it.done)) } })
            .put("notes", JSONArray().also { array -> notes.forEach { array.put(it) } })
            .put("memories", JSONArray().also { array -> memories.forEach { array.put(it) } })
            .put("messages", JSONArray().also { array -> messages.takeLast(MAX_SAVED_MESSAGES).forEach { array.put(JSONObject().put("role", it.role).put("text", it.text)) } })
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/json"
            putExtra(Intent.EXTRA_TEXT, data.toString(2))
        }
        runCatching {
            startActivity(Intent.createChooser(intent, if (isPersian) "ذخیره یا ارسال نسخه پشتیبان" else "Save or share backup"))
        }.onFailure { showActivityError() }
    }

    private fun startVoiceInput() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            toast(if (isPersian) "تشخیص گفتار روی این دستگاه در دسترس نیست." else "Speech recognition is unavailable on this device.")
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQUEST_MIC)
            return
        }
        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    toast(if (isPersian) "گوش می‌دم..." else "Listening...")
                }
                override fun onBeginningOfSpeech() = Unit
                override fun onRmsChanged(rmsdB: Float) = Unit
                override fun onBufferReceived(buffer: ByteArray?) = Unit
                override fun onEndOfSpeech() = Unit
                override fun onError(error: Int) {
                    toast(if (isPersian) "صدا تشخیص داده نشد. دوباره امتحان کن." else "Speech was not recognized. Try again.")
                }
                override fun onResults(results: Bundle?) {
                    val spoken = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (spoken.isNullOrBlank()) return
                    if (parseDeviceCommand(spoken) != null) {
                        val bubbles = activeChatBubbleList
                        val scroll = activeChatScroll
                        if (bubbles != null && scroll != null) {
                            messageInput?.setText("")
                            sendMessage(spoken, bubbles, scroll)
                        } else {
                            messageInput?.setText(spoken)
                        }
                    } else {
                        messageInput?.setText(spoken)
                    }
                }
                override fun onPartialResults(partialResults: Bundle?) = Unit
                override fun onEvent(eventType: Int, params: Bundle?) = Unit
            })
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, if (isPersian) "fa-IR" else "en-US")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            }
            startListening(intent)
        }
    }

    private fun speak(text: String) {
        if (ttsReady && text.isNotBlank()) {
            tts.speak(text.take(3500), TextToSpeech.QUEUE_FLUSH, null, "iliya-response-${System.currentTimeMillis()}")
        }
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQUEST_NOTIFICATIONS)
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            REQUEST_MIC -> if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) startVoiceInput()
            REQUEST_NOTIFICATIONS -> if (grantResults.firstOrNull() != PackageManager.PERMISSION_GRANTED) {
                toast(if (isPersian) "بدون مجوز اعلان، یادآوری‌ها نمایش داده نمی‌شوند." else "Reminders need notification permission.")
            }
            REQUEST_CONTACTS, REQUEST_CALL, REQUEST_SMS -> {
                val granted = grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED
                val action = pendingPermissionAction
                pendingPermissionAction = null
                if (granted) {
                    if (action != null) runCatching(action).onFailure { showDeviceActionError(it) }
                } else {
                    toast(pendingPermissionDeniedMessage)
                }
                pendingPermissionDeniedMessage = ""
            }
        }
    }

    private fun actionButton(text: String, primary: Boolean, onClick: () -> Unit): Button = Button(this).apply {
        this.text = text
        isAllCaps = false
        textSize = 13f
        setTextColor(if (primary) Color.rgb(8, 24, 31) else ink)
        background = rounded(if (primary) accent else panelAlt, 14)
        setPadding(dp(12), dp(4), dp(12), dp(4))
        stateListAnimator = null
        setOnClickListener { onClick() }
    }

    private fun label(text: String, size: Int, color: Int, bold: Boolean = false): TextView = TextView(this).apply {
        this.text = text
        textSize = size.toFloat()
        setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
        gravity = if (isPersian) Gravity.RIGHT else Gravity.LEFT
        textDirection = if (isPersian) View.TEXT_DIRECTION_RTL else View.TEXT_DIRECTION_LTR
        layoutDirection = direction()
        setPadding(0, dp(3), 0, dp(3))
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        layoutDirection = direction()
        setPadding(dp(14), dp(12), dp(14), dp(12))
        background = rounded(panel, 20)
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = dp(10) }
    }

    private fun rounded(color: Int, radius: Int): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
    }

    private fun direction(): Int = if (isPersian) View.LAYOUT_DIRECTION_RTL else View.LAYOUT_DIRECTION_LTR
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
    private fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    private fun toast(text: String) = Toast.makeText(this, text, Toast.LENGTH_SHORT).show()
    private fun newLocalId(): Int = (System.nanoTime() and 0x7fffffffL).toInt().coerceAtLeast(1)
    private fun showActivityError() = toast(if (isPersian) "برنامهٔ مناسب روی گوشی پیدا نشد." else "No compatible app was found on this phone.")
    private fun showDeviceActionError(error: Throwable) = toast(
        if (isPersian) "اجرای فرمان ناموفق بود: ${error.message ?: "خطای نامشخص"}"
        else "Command failed: ${error.message ?: "unknown error"}"
    )

    override fun onDestroy() {
        speechRecognizer?.cancel()
        speechRecognizer?.destroy()
        speechRecognizer = null
        if (::tts.isInitialized) tts.shutdown()
        executor.shutdownNow()
        super.onDestroy()
    }

    companion object {
        private const val PREFS_NAME = "iliya_ai"
        private const val KEY_LANGUAGE = "is_persian"
        private const val KEY_MESSAGES = "messages"
        private const val KEY_TASKS = "tasks"
        private const val KEY_NOTES = "notes"
        private const val KEY_MEMORIES = "memories"
        private const val KEY_ENDPOINT = "assistant_endpoint"
        private const val KEY_TOKEN_ENCRYPTED = "assistant_access_token_encrypted"
        private const val ANDROID_KEYSTORE = "AndroidKeyStore"
        private const val TOKEN_KEY_ALIAS = "iliya_ai_access_token_v1"
        private const val GCM_IV_BYTES = 12
        private const val GCM_TAG_BITS = 128
        private const val DEFAULT_ENDPOINT = "https://iliya-assistant.nova-b75a23.workers.dev/api/chat"
        private const val MAX_SAVED_MESSAGES = 80
        private const val MAX_VISIBLE_MESSAGES = 40
        private const val REQUEST_MIC = 20
        private const val REQUEST_NOTIFICATIONS = 21
        private const val REQUEST_CONTACTS = 22
        private const val REQUEST_CALL = 23
        private const val REQUEST_SMS = 24
    }
}
