package com.iliya.assistant

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import org.json.JSONArray
import org.json.JSONObject

internal data class StoredReminder(
    val id: Int,
    val triggerAtMillis: Long,
    val title: String,
    val message: String
)

internal object ReminderStore {
    private const val PREFS = "iliya_ai_reminders"
    private const val KEY_ITEMS = "items"

    fun all(context: Context): List<StoredReminder> = runCatching {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_ITEMS, "[]") ?: "[]"
        val array = JSONArray(raw)
        buildList {
            for (index in 0 until array.length()) {
                val item = array.optJSONObject(index) ?: continue
                val id = item.optInt("id", -1)
                val time = item.optLong("time", 0L)
                if (id >= 0 && time > 0L) {
                    add(StoredReminder(id, time, item.optString("title"), item.optString("message")))
                }
            }
        }
    }.getOrDefault(emptyList())

    fun save(context: Context, reminder: StoredReminder) {
        val items = all(context).filterNot { it.id == reminder.id } + reminder
        val array = JSONArray()
        items.forEach { item ->
            array.put(
                JSONObject()
                    .put("id", item.id)
                    .put("time", item.triggerAtMillis)
                    .put("title", item.title)
                    .put("message", item.message)
            )
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY_ITEMS, array.toString()).apply()
    }

    fun remove(context: Context, id: Int) {
        val array = JSONArray()
        all(context).filterNot { it.id == id }.forEach { item ->
            array.put(
                JSONObject()
                    .put("id", item.id)
                    .put("time", item.triggerAtMillis)
                    .put("title", item.title)
                    .put("message", item.message)
            )
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY_ITEMS, array.toString()).apply()
    }
}

internal object ReminderScheduler {
    fun schedule(context: Context, reminder: StoredReminder) {
        if (reminder.triggerAtMillis <= System.currentTimeMillis()) {
            ReminderStore.remove(context, reminder.id)
            return
        }
        val intent = Intent(context, ReminderReceiver::class.java).apply {
            putExtra(ReminderReceiver.EXTRA_TITLE, reminder.title)
            putExtra(ReminderReceiver.EXTRA_MESSAGE, reminder.message)
            putExtra(ReminderReceiver.EXTRA_ID, reminder.id)
        }
        val pending = PendingIntent.getBroadcast(
            context,
            reminder.id,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        // Inexact, idle-friendly alarm: does not require special exact-alarm access.
        alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, reminder.triggerAtMillis, pending)
    }

    fun cancel(context: Context, id: Int) {
        val intent = Intent(context, ReminderReceiver::class.java)
        val pending = PendingIntent.getBroadcast(
            context,
            id,
            intent,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (pending != null) {
            val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            alarm.cancel(pending)
            pending.cancel()
        }
        ReminderStore.remove(context, id)
    }
}
